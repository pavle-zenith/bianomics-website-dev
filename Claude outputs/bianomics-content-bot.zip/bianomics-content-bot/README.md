# Bianomics content bot

Bianca messages a Slack bot ("change the cost FAQ to say X"). The bot edits the copy in `src/content/*.ts` of the site repo, opens a PR, waits for the Vercel preview, and posts it in the thread with **Approve & publish** / **Cancel** buttons. Approve squash-merges the PR, and the bot confirms when the production deploy is live, with an **Undo** button.

```
Slack DM / @mention
  -> /api/slack/events         Claude edits content files (read, search, edit tools)
  -> GitHub: branch + commit + PR (thread id stored in the PR body, no database)
  -> Vercel builds the preview
  -> /api/github (deployment_status webhook) posts the preview + buttons
  -> /api/slack/interactions   Approve = merge at the previewed commit, Cancel = close
  -> production deployment_status posts "It's live" + Undo
```

## Guardrails

- Only Slack users in `ALLOWED_SLACK_USER_IDS` can request changes or press buttons.
- Only files in `src/content/` can be edited. `types.ts`, `index.ts` and `legal.ts` are read-only (`READONLY_FILES`).
- Each edit is syntax-checked before it's committed. A broken edit is rejected and the model has to fix it.
- Exports whose doc comment says "locked" (currently `brand` and `snapshot` in `site.ts`) can only be changed when Bianca gives the exact wording. These changes are flagged with a lock icon in Slack.
- Nothing merges without a successful preview and a click on Approve. The merge is pinned to the exact commit that was previewed.
- Undo refuses to run if the same file has been edited again since, so it never wipes newer changes.
- Out of scope, and the bot says so: layout, design, images, new sections, legal pages.

## Setup (about 30-45 min)

### 1. Deploy the bot
1. Push this folder to a new **private** GitHub repo, e.g. `pavle-zenith/bianomics-content-bot`.
2. Import it in Vercel, in the same team as the site, and deploy. Note the URL, e.g. `https://bianomics-content-bot.vercel.app`. The env vars come later, so requests will fail until then. That's expected.

### 2. GitHub token (for the site repo)
In GitHub, go to Settings > Developer settings > Fine-grained tokens > Generate new token:
- Repository access: **Only select repositories** > `bianomics-website-dev`
- Permissions: **Contents: Read and write**, **Pull requests: Read and write** (Metadata: read is added automatically)
- Expiry: the longest allowed. Add a calendar reminder to rotate it.

Commits are authored as you (the token owner). This matters: Vercel only builds private-repo commits from authors on the Vercel team.

### 3. Webhook on the site repo
Go to `bianomics-website-dev` > Settings > Webhooks > Add webhook:
- Payload URL: `https://<bot>/api/github`
- Content type: `application/json`
- Secret: any long random string. The same value goes in `GITHUB_WEBHOOK_SECRET`.
- Events: **Let me select individual events** > tick only **Deployment statuses**

Vercel's GitHub integration already creates GitHub deployments for each preview and production build. You can see them under "Deployments" in the repo sidebar, and that's what this webhook listens to.

### 4. Let Bianca open previews
She isn't on your Vercel team, so in the **site** Vercel project go to Settings > Deployment Protection and set **Vercel Authentication** to off. Otherwise she hits a Vercel login page. Preview URLs are unguessable, and this is a marketing site.

### 5. Slack app (in the Bianomics workspace)
1. Go to api.slack.com/apps > Create New App > **From a manifest**, pick the Bianomics workspace, and paste `slack-manifest.yml` with `YOUR-BOT` replaced by your bot's domain.
2. Click **Install to Workspace**. If the workspace requires admin approval, Bianca approves it.
3. Copy the **Bot User OAuth Token** (`xoxb-...`) and, under Basic Information, the **Signing Secret**.
4. Get member IDs for Bianca and for you: Slack profile > ⋯ > Copy member ID.

### 6. Env vars in Vercel (bot project), then redeploy
See `.env.example`:

| Var | Value |
|---|---|
| `SLACK_BOT_TOKEN` | `xoxb-...` |
| `SLACK_SIGNING_SECRET` | from Basic Information |
| `ALLOWED_SLACK_USER_IDS` | `UBIANCA,UPAVLE` |
| `ANTHROPIC_API_KEY` | from platform.claude.com (set a monthly spend limit there) |
| `ANTHROPIC_MODEL` | `claude-sonnet-5-5` (default) |
| `GITHUB_TOKEN` | the fine-grained token |
| `GITHUB_REPO` | `pavle-zenith/bianomics-website-dev` |
| `GITHUB_BASE_BRANCH` | `main` |
| `GITHUB_WEBHOOK_SECRET` | same as the webhook |
| `SITE_URL` | `https://bianomics.com` |

After redeploying, open the Slack app's **Event Subscriptions** page. The request URL should show as Verified. If not, click Retry.

### 7. Test
DM **Site Editor** with something like: `Change the FAQ answer about cost to start with "Every engagement is scoped to what you need."` You should get, in order:
1. The change and a before/after.
2. The preview link with buttons.
3. After you approve, the merge, then "It's live".

In a channel, @mention the bot. Follow-ups in the thread need the @mention too. In DMs, plain replies in the thread work.

## Local

```
npm install
npm test                       # unit + end-to-end flow tests (Slack/GitHub/Claude mocked)
ANTHROPIC_API_KEY=sk-ant-... npm run try -- ../bianomics-website-dev "make the cost FAQ answer shorter"
```

`try` runs the real agent against a local checkout of the site and prints the edits. Add `--write` to save them to disk. It's handy for checking how it handles a request before involving Slack.

## Running costs

- **Claude API:** about $0.05-0.15 per change request, using Sonnet 5.5 at $2 / $10 per million input/output tokens. A typical request reads a content file or two and makes a few tool calls. At 30-50 requests a month, that's roughly $2-8/month.
- **Vercel:** about 5 seconds to 1 minute of function time per request. That's $0 extra on an existing Pro team, and within Hobby limits too. Note that Hobby is meant for non-commercial use.
- **Slack:** $0. Custom apps work on the free plan, which allows up to 10 apps/integrations.
- **GitHub:** $0. It doesn't need branch protection (a paid feature on private repos), because the bot only merges after a successful preview.
