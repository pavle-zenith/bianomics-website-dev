import type { NextConfig } from 'next'

const nextConfig: NextConfig = {
  // typescript is used at runtime to syntax-check edited content files.
  serverExternalPackages: ['typescript'],
}

export default nextConfig
