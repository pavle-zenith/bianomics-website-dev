/**
 * Environment config. Read lazily so `next build` works without secrets.
 */
function required(name: string): string {
  const value = process.env[name]
  if (!value) throw new Error(`Missing environment variable ${name}`)
  return value
}

function list(value: string | undefined): string[] {
  return (value ?? '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean)
}

export const config = {
  get slackBotToken() {
    return required('SLACK_BOT_TOKEN')
  },
  get slackSigningSecret() {
    return required('SLACK_SIGNING_SECRET')
  },
  get allowedUsers() {
    return list(required('ALLOWED_SLACK_USER_IDS'))
  },
  get anthropicKey() {
    return required('ANTHROPIC_API_KEY')
  },
  get model() {
    return process.env.ANTHROPIC_MODEL || 'claude-sonnet-5-5'
  },
  get githubToken() {
    return required('GITHUB_TOKEN')
  },
  get repo() {
    const [owner, name] = required('GITHUB_REPO').split('/')
    if (!owner || !name) throw new Error('GITHUB_REPO must look like owner/name')
    return { owner, name }
  },
  get baseBranch() {
    return process.env.GITHUB_BASE_BRANCH || 'main'
  },
  get githubWebhookSecret() {
    return required('GITHUB_WEBHOOK_SECRET')
  },
  get contentDir() {
    return (process.env.CONTENT_DIR || 'src/content').replace(/\/+$/, '')
  },
  get readonlyFiles() {
    const raw = process.env.READONLY_FILES
    return raw === undefined ? ['types.ts', 'index.ts', 'legal.ts'] : list(raw)
  },
  get siteUrl() {
    return process.env.SITE_URL || ''
  },
}

/** Every branch the bot creates starts with this, so its PRs are easy to tell apart. */
export const BRANCH_PREFIX = 'content-bot/'
