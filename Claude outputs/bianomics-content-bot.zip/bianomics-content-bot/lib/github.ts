import { config } from './config'

async function gh<T = any>(path: string, init: RequestInit & { raw?: boolean } = {}): Promise<T> {
  const { owner, name } = config.repo
  const url = path.startsWith('/repos/')
    ? `https://api.github.com${path}`
    : `https://api.github.com/repos/${owner}/${name}${path}`
  const res = await fetch(url, {
    ...init,
    headers: {
      Authorization: `Bearer ${config.githubToken}`,
      Accept: init.raw ? 'application/vnd.github.raw+json' : 'application/vnd.github+json',
      'X-GitHub-Api-Version': '2022-11-28',
      ...(init.body ? { 'Content-Type': 'application/json' } : {}),
      ...(init.headers ?? {}),
    },
    cache: 'no-store',
  })
  if (!res.ok) {
    const body = await res.text()
    const err = new Error(`GitHub ${init.method ?? 'GET'} ${path} -> ${res.status}: ${body.slice(0, 300)}`)
    ;(err as Error & { status?: number }).status = res.status
    throw err
  }
  if (res.status === 204) return undefined as T
  return (init.raw ? await res.text() : await res.json()) as T
}

function enc(path: string): string {
  return path.split('/').map(encodeURIComponent).join('/')
}

export interface PullRequest {
  number: number
  title: string
  body: string | null
  state: 'open' | 'closed'
  merged: boolean
  merged_at: string | null
  merge_commit_sha: string | null
  html_url: string
  head: { ref: string; sha: string }
  base: { ref: string }
}

export async function getBranchSha(branch: string): Promise<string | null> {
  try {
    const ref = await gh<{ object: { sha: string } }>(`/git/ref/heads/${enc(branch)}`)
    return ref.object.sha
  } catch (e) {
    if ((e as { status?: number }).status === 404) return null
    throw e
  }
}

/** Raw file text at a ref, or null if it doesn't exist there. */
export async function getFile(path: string, ref: string): Promise<string | null> {
  try {
    return await gh<string>(`/contents/${enc(path)}?ref=${encodeURIComponent(ref)}`, { raw: true })
  } catch (e) {
    if ((e as { status?: number }).status === 404) return null
    throw e
  }
}

export async function listDir(path: string, ref: string): Promise<string[]> {
  const items = await gh<{ name: string; type: string }[]>(
    `/contents/${enc(path)}?ref=${encodeURIComponent(ref)}`,
  )
  return items.filter((i) => i.type === 'file').map((i) => i.name)
}

export async function createBranch(branch: string, fromSha: string): Promise<void> {
  await gh('/git/refs', {
    method: 'POST',
    body: JSON.stringify({ ref: `refs/heads/${branch}`, sha: fromSha }),
  })
}

export async function deleteBranch(branch: string): Promise<void> {
  try {
    await gh(`/git/refs/heads/${enc(branch)}`, { method: 'DELETE' })
  } catch (e) {
    // Already gone (e.g. GitHub auto-deletes merged branches) is fine.
    const status = (e as { status?: number }).status
    if (status !== 422 && status !== 404) throw e
  }
}

/**
 * One commit with all changed files, on top of `parentSha`, then move the
 * branch to it. The author defaults to the token's owner, which matters:
 * Vercel only builds private-repo commits from authors on the Vercel team.
 */
export async function commitFiles(opts: {
  branch: string
  parentSha: string
  files: { path: string; content: string }[]
  message: string
}): Promise<string> {
  const parent = await gh<{ tree: { sha: string } }>(`/git/commits/${opts.parentSha}`)
  const tree = await gh<{ sha: string }>('/git/trees', {
    method: 'POST',
    body: JSON.stringify({
      base_tree: parent.tree.sha,
      tree: opts.files.map((f) => ({ path: f.path, mode: '100644', type: 'blob', content: f.content })),
    }),
  })
  const commit = await gh<{ sha: string }>('/git/commits', {
    method: 'POST',
    body: JSON.stringify({ message: opts.message, tree: tree.sha, parents: [opts.parentSha] }),
  })
  await gh(`/git/refs/heads/${enc(opts.branch)}`, {
    method: 'PATCH',
    body: JSON.stringify({ sha: commit.sha, force: false }),
  })
  return commit.sha
}

export async function createPr(opts: { head: string; base: string; title: string; body: string }): Promise<PullRequest> {
  return gh<PullRequest>('/pulls', { method: 'POST', body: JSON.stringify(opts) })
}

export async function getPr(number: number): Promise<PullRequest> {
  return gh<PullRequest>(`/pulls/${number}`)
}

export async function listOpenPrs(): Promise<PullRequest[]> {
  return gh<PullRequest[]>('/pulls?state=open&per_page=100')
}

export async function prsForCommit(sha: string): Promise<PullRequest[]> {
  return gh<PullRequest[]>(`/commits/${sha}/pulls`)
}

export async function prFiles(number: number): Promise<{ filename: string; status: string }[]> {
  return gh(`/pulls/${number}/files?per_page=100`)
}

export async function getCommitParents(sha: string): Promise<string[]> {
  const c = await gh<{ parents: { sha: string }[] }>(`/git/commits/${sha}`)
  return c.parents.map((p) => p.sha)
}

/** Squash-merge, but only if the PR head is still `sha` (what she previewed). */
export async function mergePr(number: number, sha: string, title: string): Promise<void> {
  await gh(`/pulls/${number}/merge`, {
    method: 'PUT',
    body: JSON.stringify({ merge_method: 'squash', sha, commit_title: title }),
  })
}

export async function closePr(number: number): Promise<void> {
  await gh(`/pulls/${number}`, { method: 'PATCH', body: JSON.stringify({ state: 'closed' }) })
}

export async function commentOnPr(number: number, body: string): Promise<void> {
  await gh(`/issues/${number}/comments`, { method: 'POST', body: JSON.stringify({ body }) })
}
