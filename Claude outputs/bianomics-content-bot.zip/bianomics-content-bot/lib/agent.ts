import Anthropic from '@anthropic-ai/sdk'
import { applyEdit, searchFiles, WorkingSet } from './content'

export interface EditLogEntry {
  file: string
  description: string
  before: string
  after: string
  locked?: string
}

export interface AgentResult {
  reply: string
  edits: EditLogEntry[]
  changed: { name: string; content: string }[]
}

export interface AgentOptions {
  client: Pick<Anthropic, 'messages'>
  model: string
  /** Conversation so far; must start and end with a user turn. */
  history: Anthropic.MessageParam[]
  /** File names (e.g. "site.ts") in the content folder. */
  files: string[]
  /** Subset of `files` that can be read but never edited. */
  readonly: string[]
  load: (name: string) => Promise<string | null>
  siteName?: string
  maxTurns?: number
}

const TOOLS: Anthropic.Tool[] = [
  {
    name: 'list_files',
    description: 'List the website content files and which of them are editable.',
    input_schema: { type: 'object', properties: {} },
  },
  {
    name: 'search',
    description:
      'Case-insensitive text search across all content files. Returns matching lines as file:line: text. Use short distinctive phrases from what the user quoted or described.',
    input_schema: {
      type: 'object',
      properties: { query: { type: 'string', description: 'Text to look for' } },
      required: ['query'],
    },
  },
  {
    name: 'read_file',
    description: 'Read a content file in full (including any edits you already made in this conversation).',
    input_schema: {
      type: 'object',
      properties: { file: { type: 'string', description: 'File name, e.g. site.ts' } },
      required: ['file'],
    },
  },
  {
    name: 'edit_file',
    description:
      'Replace one exact, unique piece of text in an editable content file. old_str must match the file exactly (copy it from read_file) and appear only once. The result is syntax-checked; a broken edit is rejected.',
    input_schema: {
      type: 'object',
      properties: {
        file: { type: 'string' },
        old_str: { type: 'string', description: 'Exact existing text, unique in the file' },
        new_str: { type: 'string', description: 'Replacement text' },
        description: {
          type: 'string',
          description:
            'Plain-English label for this change as the user would say it, e.g. "About section intro" or "FAQ: How much does it cost?"',
        },
        confirm_locked: {
          type: 'boolean',
          description:
            'Only set true when editing locked brand language AND the user supplied the exact new wording verbatim.',
        },
      },
      required: ['file', 'old_str', 'new_str', 'description'],
    },
  },
]

function systemPrompt(siteName: string, files: string[], readonly: string[]): string {
  const editable = files.filter((f) => !readonly.includes(f))
  return `You are the content assistant for the ${siteName} website. The site owner messages you in Slack to change website copy. Every change you make becomes a preview she must approve before it goes live, so you can act on clear requests without asking permission first.

The site is a Next.js codebase. All visible copy lives in TypeScript content files (${editable.join(', ')}). Read-only for you: ${readonly.join(', ') || 'none'}.

How to work:
- Find the text first: use search with a phrase she quoted or a distinctive word, then read_file around it. Comments in the files explain what each field is and where it shows on the page; read them.
- Edit with edit_file, changing only string values. Never touch types, imports, ids, hrefs, color keys, photo slugs, or code structure.
- Keep the file valid TypeScript: escape apostrophes in single-quoted strings or switch that string to double quotes, as the file already does elsewhere.
- Some copy is stored more than once for layout reasons (for example a full sentence plus the same sentence split into lines or columns, or a lead-in plus the rest of a headline). The comments say so. When you change one, update its twins so they always match.
- Text in an export whose comment says "locked" is fixed brand language. Do not reword it yourself. Only change it if she gives the exact new wording, then use confirm_locked: true.
- When she asks you to write or rewrite copy (not just swap in her exact words), match the existing voice: plain, warm, confident, short sentences, no jargon, and the same punctuation habits the file already uses.

Out of scope, so do not edit, and say Pavle (her developer) will handle it: layout, design, colors, fonts, images or photos, adding or removing whole sections or pages, anything in the legal pages (privacy, terms), tracking, forms, and anything that is not a text change. Adding or removing an item in an existing list (an FAQ, a team member's bio text, a step) is fine if the shape stays the same, except team photos.

If the request is ambiguous (you can't tell which text she means, or it matches several places), ask one short question and make no edits. If she asks a question about what the site says, answer it from the files without editing.

Your final message goes straight to her in Slack. Keep it to one to three short sentences in plain English: what you changed (or what you need from her). No file names, code, or line numbers. Slack formatting: *bold* with single asterisks, no headings.`
}

export async function runAgent(opts: AgentOptions): Promise<AgentResult> {
  const ws = new WorkingSet(opts.load)
  const edits: EditLogEntry[] = []
  const messages: Anthropic.MessageParam[] = [...opts.history]
  const system = systemPrompt(opts.siteName ?? 'client', opts.files, opts.readonly)
  const maxTurns = opts.maxTurns ?? 20

  const canRead = (f: string) => opts.files.includes(f)
  const canEdit = (f: string) => canRead(f) && !opts.readonly.includes(f)

  async function runTool(name: string, input: Record<string, unknown>): Promise<string> {
    switch (name) {
      case 'list_files':
        return opts.files.map((f) => `${f}${canEdit(f) ? '' : ' (read-only)'}`).join('\n')

      case 'search': {
        const all: Record<string, string> = {}
        for (const f of opts.files) {
          const text = await ws.get(f)
          if (text !== null) all[f] = text
        }
        const hits = searchFiles(all, String(input.query ?? ''))
        return hits.length ? hits.join('\n') : 'No matches.'
      }

      case 'read_file': {
        const file = String(input.file ?? '')
        if (!canRead(file)) return `Unknown file "${file}". Files: ${opts.files.join(', ')}`
        const text = await ws.get(file)
        if (text === null) return `File "${file}" not found.`
        return text
          .split('\n')
          .map((l, i) => `${String(i + 1).padStart(4)}  ${l}`)
          .join('\n')
      }

      case 'edit_file': {
        const file = String(input.file ?? '')
        if (!canEdit(file)) return `"${file}" cannot be edited. Editable files: ${opts.files.filter(canEdit).join(', ')}`
        const text = await ws.get(file)
        if (text === null) return `File "${file}" not found.`
        const oldStr = String(input.old_str ?? '')
        const newStr = String(input.new_str ?? '')
        const res = applyEdit(text, oldStr, newStr, {
          fileName: file,
          allowLocked: input.confirm_locked === true,
        })
        if (!res.ok) return `Edit rejected: ${res.error}`
        ws.set(file, res.content!)
        edits.push({
          file,
          description: String(input.description ?? 'Text change'),
          before: oldStr,
          after: newStr,
          locked: res.locked,
        })
        return 'Edit applied.'
      }

      default:
        return `Unknown tool ${name}`
    }
  }

  for (let turn = 0; turn < maxTurns; turn++) {
    const response = await opts.client.messages.create({
      model: opts.model,
      max_tokens: 4096,
      system,
      tools: TOOLS,
      messages,
    })
    messages.push({ role: 'assistant', content: response.content })

    const toolUses = response.content.filter((b): b is Anthropic.ToolUseBlock => b.type === 'tool_use')
    if (response.stop_reason !== 'tool_use' || toolUses.length === 0) {
      const reply = response.content
        .filter((b): b is Anthropic.TextBlock => b.type === 'text')
        .map((b) => b.text)
        .join('\n')
        .trim()
      return { reply: reply || 'Done.', edits, changed: ws.changed() }
    }

    const results: Anthropic.ToolResultBlockParam[] = []
    for (const tu of toolUses) {
      let output: string
      try {
        output = await runTool(tu.name, (tu.input ?? {}) as Record<string, unknown>)
      } catch (e) {
        output = `Tool error: ${(e as Error).message}`
      }
      results.push({ type: 'tool_result', tool_use_id: tu.id, content: output })
    }
    messages.push({ role: 'user', content: results })
  }

  return {
    reply: "I couldn't finish that one in a reasonable number of steps. Could you say it a bit more specifically?",
    edits: [],
    changed: [],
  }
}

/**
 * Slack thread -> Claude conversation. Bot messages become assistant turns,
 * people's messages user turns; consecutive same-role turns are merged.
 */
export function threadToHistory(
  thread: { text: string; bot_id?: string; ts: string }[],
  opts: { skipTs?: string[]; botUserId?: string } = {},
): Anthropic.MessageParam[] {
  const out: { role: 'user' | 'assistant'; text: string }[] = []
  for (const m of thread) {
    if (opts.skipTs?.includes(m.ts)) continue
    let text = (m.text ?? '').trim()
    if (opts.botUserId) text = text.replaceAll(`<@${opts.botUserId}>`, '').trim()
    if (!text) continue
    const role = m.bot_id ? 'assistant' : 'user'
    const last = out[out.length - 1]
    if (last && last.role === role) last.text += '\n\n' + text
    else out.push({ role, text })
  }
  while (out.length && out[0].role !== 'user') out.shift()
  while (out.length && out[out.length - 1].role !== 'user') out.pop()
  return out.map((m) => ({ role: m.role, content: m.text }))
}
