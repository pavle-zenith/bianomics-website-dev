/**
 * The bot's workflows: a Slack message becomes a PR, a Vercel preview becomes
 * an Approve button, Approve merges, the production deploy confirms it's live.
 *
 * No database: the Slack thread is stored in a marker inside the PR body, and
 * buttons carry the PR number and commit they refer to.
 */
import Anthropic from '@anthropic-ai/sdk'
import { runAgent, threadToHistory, type EditLogEntry } from './agent'
import { BRANCH_PREFIX, config } from './config'
import * as gh from './github'
import * as slack from './slack'

const SITE_NAME = 'Bianomics'

// ---------------------------------------------------------------------------
// Thread <-> PR mapping

function marker(channel: string, threadTs: string): string {
  return `<!-- content-bot:${channel}:${threadTs} -->`
}

export function parseMarker(body: string | null): { channel: string; threadTs: string } | null {
  const m = body?.match(/<!-- content-bot:([A-Z0-9]+):([0-9.]+) -->/)
  return m ? { channel: m[1], threadTs: m[2] } : null
}

async function openPrForThread(channel: string, threadTs: string): Promise<gh.PullRequest | null> {
  const tag = marker(channel, threadTs)
  const prs = await gh.listOpenPrs()
  return prs.find((p) => p.head.ref.startsWith(BRANCH_PREFIX) && (p.body ?? '').includes(tag)) ?? null
}

function newBranchName(threadTs: string): string {
  return `${BRANCH_PREFIX}${threadTs.replace('.', '-')}-${Date.now().toString(36)}`
}

function contentPath(name: string): string {
  return `${config.contentDir}/${name}`
}

// ---------------------------------------------------------------------------
// Formatting

function quote(text: string, max = 600): string {
  const t = slack.truncate(text.trim(), max)
  return t
    .split('\n')
    .map((l) => `> ${slack.esc(l)}`)
    .join('\n')
}

function changeBlocks(edits: EditLogEntry[]): slack.Block[] {
  const blocks: slack.Block[] = []
  for (const e of edits.slice(0, 8)) {
    const lock = e.locked ? ' :lock: _locked brand language_' : ''
    blocks.push(
      slack.section(`*${slack.esc(e.description)}*${lock}\n_Before_\n${quote(e.before)}\n_After_\n${quote(e.after)}`),
    )
  }
  if (edits.length > 8) blocks.push(slack.context(`…and ${edits.length - 8} more changes.`))
  return blocks
}

function prBody(channel: string, threadTs: string, request: string, edits: EditLogEntry[]): string {
  const lines = [
    marker(channel, threadTs),
    `Requested in Slack:`,
    '',
    request
      .split('\n')
      .map((l) => `> ${l}`)
      .join('\n'),
    '',
    `Changes:`,
    ...edits.map((e) => `- ${e.description} (\`${e.file}\`)${e.locked ? ' - locked brand language' : ''}`),
    '',
    '_Opened by the content bot. Merged only when approved in Slack after a successful Vercel preview._',
  ]
  return lines.join('\n')
}

// ---------------------------------------------------------------------------
// 1. A message from Bianca

export async function handleMessage(opts: {
  channel: string
  threadTs: string
  messageTs: string
  user: string
  text: string
  botUserId?: string
}): Promise<void> {
  const { channel, threadTs } = opts
  const statusTs = await slack.postMessage({ channel, threadTs, text: ':hourglass_flowing_sand: On it…' })

  try {
    const thread = await slack.getThread(channel, threadTs)
    const history = threadToHistory(thread, { skipTs: [statusTs], botUserId: opts.botUserId })
    if (!history.length) {
      await slack.updateMessage({ channel, ts: statusTs, text: 'What would you like to change on the site?' })
      return
    }

    // Follow-ups in a thread build on the open PR for that thread.
    const pr = await openPrForThread(channel, threadTs)
    const ref = pr ? pr.head.ref : config.baseBranch

    const files = (await gh.listDir(config.contentDir, ref)).filter((f) => /\.(ts|tsx|json|md|mdx)$/.test(f))
    const result = await runAgent({
      client: new Anthropic({ apiKey: config.anthropicKey }),
      model: config.model,
      history,
      files,
      readonly: config.readonlyFiles,
      load: (name) => gh.getFile(contentPath(name), ref),
      siteName: SITE_NAME,
    })

    if (!result.changed.length) {
      await slack.updateMessage({ channel, ts: statusTs, text: result.reply, blocks: [slack.section(result.reply)] })
      return
    }

    const request = opts.text.replaceAll(`<@${opts.botUserId}>`, '').trim()
    const commitMessage = `content: ${slack.truncate(request.split('\n')[0] || 'copy update', 72)}`
    const files_ = result.changed.map((c) => ({ path: contentPath(c.name), content: c.content }))

    let prNumber: number
    let prUrl: string
    if (pr) {
      const head = (await gh.getBranchSha(pr.head.ref))!
      await gh.commitFiles({ branch: pr.head.ref, parentSha: head, files: files_, message: commitMessage })
      await gh.commentOnPr(pr.number, `Follow-up from Slack:\n\n> ${request}`)
      prNumber = pr.number
      prUrl = pr.html_url
    } else {
      const baseSha = await gh.getBranchSha(config.baseBranch)
      if (!baseSha) throw new Error(`Base branch ${config.baseBranch} not found`)
      const branch = newBranchName(threadTs)
      await gh.createBranch(branch, baseSha)
      await gh.commitFiles({ branch, parentSha: baseSha, files: files_, message: commitMessage })
      const created = await gh.createPr({
        head: branch,
        base: config.baseBranch,
        title: commitMessage,
        body: prBody(channel, threadTs, request, result.edits),
      })
      prNumber = created.number
      prUrl = created.html_url
    }

    await slack.updateMessage({
      channel,
      ts: statusTs,
      text: result.reply,
      blocks: [
        slack.section(result.reply),
        ...changeBlocks(result.edits),
        slack.context(
          `:hammer_and_wrench: Building a preview. I'll post the link here in a minute or two. · <${prUrl}|PR #${prNumber}>`,
        ),
      ],
    })
  } catch (e) {
    console.error('handleMessage failed', e)
    await slack.updateMessage({
      channel,
      ts: statusTs,
      text: `:warning: Something went wrong on my side, nothing was changed. Pavle can check the logs. (${slack.esc((e as Error).message).slice(0, 200)})`,
    })
  }
}

// ---------------------------------------------------------------------------
// 2. Vercel finished a deployment (GitHub deployment_status webhook)

interface DeploymentStatusPayload {
  deployment_status: { state: string; environment_url?: string; target_url?: string }
  deployment: { sha: string; environment: string; ref: string }
}

export async function handleDeploymentStatus(p: DeploymentStatusPayload): Promise<void> {
  const state = p.deployment_status.state
  if (!['success', 'failure', 'error'].includes(state)) return

  const isProduction = /production/i.test(p.deployment.environment)
  const url = p.deployment_status.environment_url || p.deployment_status.target_url || ''
  const prs = await gh.prsForCommit(p.deployment.sha)

  if (isProduction) {
    // A merge commit of one of our PRs just went live.
    const pr = prs.find((x) => x.merge_commit_sha === p.deployment.sha && x.head.ref.startsWith(BRANCH_PREFIX))
    const where = pr && parseMarker(pr.body)
    if (!pr || !where) return
    if (state !== 'success') {
      await slack.postMessage({
        ...where,
        text: ':warning: The approved change failed to deploy to the live site. Pavle has been flagged; the site is still showing the previous version.',
      })
      return
    }
    const live = config.siteUrl || url
    await slack.postMessage({
      ...where,
      text: ':white_check_mark: It is live.',
      blocks: [
        slack.section(`:white_check_mark: *It's live.*${live ? ` <${live}|View the site>` : ''}`),
        slack.actions([slack.button({ text: 'Undo this change', actionId: 'undo', value: String(pr.number) })]),
      ],
    })
    return
  }

  // Preview: only care about the latest commit of an open bot PR.
  const pr = prs.find(
    (x) => x.state === 'open' && x.head.ref.startsWith(BRANCH_PREFIX) && x.head.sha === p.deployment.sha,
  )
  const where = pr && parseMarker(pr.body)
  if (!pr || !where) return

  if (state === 'success') {
    const value = JSON.stringify({ pr: pr.number, sha: p.deployment.sha })
    await slack.postMessage({
      ...where,
      text: 'Preview ready',
      blocks: [
        slack.section(
          `:eyes: *Preview ready:* <${url}|open the preview>\nHappy with it? Approve to publish, or reply in this thread to tweak it.`,
        ),
        slack.actions([
          slack.button({ text: 'Approve & publish', actionId: 'approve', value, style: 'primary' }),
          slack.button({ text: 'Cancel', actionId: 'cancel', value, style: 'danger' }),
        ]),
      ],
    })
  } else {
    const value = JSON.stringify({ pr: pr.number, sha: p.deployment.sha })
    await slack.postMessage({
      ...where,
      text: 'The preview failed to build',
      blocks: [
        slack.section(
          `:x: The preview failed to build, so this change can't go live as is. Reply here to try it differently, or cancel. <${pr.html_url}|PR #${pr.number}> for Pavle.`,
        ),
        slack.actions([slack.button({ text: 'Cancel', actionId: 'cancel', value, style: 'danger' })]),
      ],
    })
  }
}

// ---------------------------------------------------------------------------
// 3. Button clicks

interface InteractionPayload {
  type: string
  user: { id: string }
  channel: { id: string }
  container: { message_ts: string; thread_ts?: string }
  message?: { ts: string; thread_ts?: string; text?: string }
  actions: { action_id: string; value: string }[]
}

export async function handleInteraction(p: InteractionPayload): Promise<void> {
  const action = p.actions?.[0]
  if (!action) return
  const channel = p.channel.id
  const messageTs = p.container.message_ts
  const threadTs = p.message?.thread_ts ?? p.container.thread_ts ?? messageTs
  const who = `<@${p.user.id}>`

  if (!config.allowedUsers.includes(p.user.id)) {
    await slack.postMessage({ channel, threadTs, text: `Sorry ${who}, only approved people can use these buttons.` })
    return
  }

  try {
    if (action.action_id === 'approve' || action.action_id === 'cancel') {
      const { pr: number, sha } = JSON.parse(action.value) as { pr: number; sha: string }
      const pr = await gh.getPr(number)
      if (pr.state !== 'open') {
        await slack.updateMessage({ channel, ts: messageTs, text: 'This change was already handled.' })
        return
      }

      if (action.action_id === 'cancel') {
        await gh.closePr(number)
        await gh.deleteBranch(pr.head.ref)
        await slack.updateMessage({
          channel,
          ts: messageTs,
          text: `Cancelled by ${who}. Nothing changed on the live site.`,
          blocks: [slack.section(`:wastebasket: Cancelled by ${who}. Nothing changed on the live site.`)],
        })
        return
      }

      if (pr.head.sha !== sha) {
        await slack.postMessage({
          channel,
          threadTs,
          text: 'There is a newer version of this change. Please use the Approve button on the latest preview.',
        })
        return
      }
      await gh.mergePr(number, sha, pr.title)
      await gh.deleteBranch(pr.head.ref)
      await slack.updateMessage({
        channel,
        ts: messageTs,
        text: `Approved by ${who}. Publishing now.`,
        blocks: [
          slack.section(`:rocket: Approved by ${who}. Publishing now, I'll confirm here when it's live.`),
        ],
      })
      return
    }

    if (action.action_id === 'undo') {
      await slack.updateMessage({
        channel,
        ts: messageTs,
        text: 'Undo requested',
        blocks: [slack.section(`:leftwards_arrow_with_hook: Undo requested by ${who}. Preparing it…`)],
      })
      await createUndoPr(Number(action.value), channel, threadTs)
    }
  } catch (e) {
    console.error('handleInteraction failed', e)
    await slack.postMessage({
      channel,
      threadTs,
      text: `:warning: That didn't work: ${slack.esc((e as Error).message).slice(0, 300)}. Pavle can take a look.`,
    })
  }
}

/**
 * Put the files a merged PR touched back to how they were before it, as a new
 * PR in the same thread (so it gets a preview + approval like anything else).
 * Refuses if those files changed again since, rather than wiping later edits.
 */
async function createUndoPr(number: number, channel: string, threadTs: string): Promise<void> {
  const pr = await gh.getPr(number)
  if (!pr.merged || !pr.merge_commit_sha) throw new Error(`PR #${number} isn't merged`)
  const [before] = await gh.getCommitParents(pr.merge_commit_sha)
  const files = await gh.prFiles(number)
  const baseSha = (await gh.getBranchSha(config.baseBranch))!

  const restored: { path: string; content: string }[] = []
  for (const f of files) {
    const atMerge = await gh.getFile(f.filename, pr.merge_commit_sha)
    const now = await gh.getFile(f.filename, baseSha)
    if (atMerge !== now) {
      await slack.postMessage({
        channel,
        threadTs,
        text: "That page's text has been changed again since, so an automatic undo could wipe out the newer edits. Just tell me in words what it should say instead.",
      })
      return
    }
    const old = await gh.getFile(f.filename, before)
    if (old !== null) restored.push({ path: f.filename, content: old })
  }
  if (!restored.length) throw new Error('Nothing to undo')

  const branch = newBranchName(threadTs)
  await gh.createBranch(branch, baseSha)
  await gh.commitFiles({ branch, parentSha: baseSha, files: restored, message: `Undo: ${pr.title}` })
  const undo = await gh.createPr({
    head: branch,
    base: config.baseBranch,
    title: `Undo: ${pr.title}`,
    body: `${marker(channel, threadTs)}\nUndoes #${number}, requested in Slack.`,
  })
  await slack.postMessage({
    channel,
    threadTs,
    text: `:hammer_and_wrench: Building a preview of the undo. I'll post it here for approval. · <${undo.html_url}|PR #${undo.number}>`,
  })
}
