import { config } from './config'

// Slack Block Kit blocks are plain JSON; keep the type loose.
export type Block = Record<string, unknown>

async function slack<T = Record<string, unknown>>(method: string, body: Record<string, unknown>): Promise<T> {
  const res = await fetch(`https://slack.com/api/${method}`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${config.slackBotToken}`,
      'Content-Type': 'application/json; charset=utf-8',
    },
    body: JSON.stringify(body),
  })
  const json = (await res.json()) as { ok: boolean; error?: string } & T
  if (!json.ok) throw new Error(`Slack ${method} failed: ${json.error}`)
  return json
}

export async function postMessage(opts: {
  channel: string
  threadTs: string
  text: string
  blocks?: Block[]
}): Promise<string> {
  const res = await slack<{ ts: string }>('chat.postMessage', {
    channel: opts.channel,
    thread_ts: opts.threadTs,
    text: opts.text,
    blocks: opts.blocks,
    unfurl_links: false,
    unfurl_media: false,
  })
  return res.ts
}

export async function updateMessage(opts: {
  channel: string
  ts: string
  text: string
  blocks?: Block[]
}): Promise<void> {
  await slack('chat.update', {
    channel: opts.channel,
    ts: opts.ts,
    text: opts.text,
    // Passing an empty array clears old buttons.
    blocks: opts.blocks ?? [],
  })
}

export interface ThreadMessage {
  ts: string
  text: string
  user?: string
  bot_id?: string
}

export async function getThread(channel: string, threadTs: string): Promise<ThreadMessage[]> {
  const res = await slack<{ messages: ThreadMessage[] }>('conversations.replies', {
    channel,
    ts: threadTs,
    limit: 200,
  })
  return res.messages ?? []
}

/** Escape text for Slack mrkdwn. */
export function esc(text: string): string {
  return text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
}

export function section(text: string): Block {
  // Slack caps section text at 3000 chars.
  return { type: 'section', text: { type: 'mrkdwn', text: truncate(text, 2900) } }
}

export function context(text: string): Block {
  return { type: 'context', elements: [{ type: 'mrkdwn', text: truncate(text, 2900) }] }
}

export function button(opts: {
  text: string
  actionId: string
  value: string
  style?: 'primary' | 'danger'
  url?: string
}): Record<string, unknown> {
  return {
    type: 'button',
    text: { type: 'plain_text', text: opts.text, emoji: true },
    action_id: opts.actionId,
    value: opts.value,
    ...(opts.style ? { style: opts.style } : {}),
    ...(opts.url ? { url: opts.url } : {}),
  }
}

export function actions(elements: Record<string, unknown>[]): Block {
  return { type: 'actions', elements }
}

export function truncate(text: string, max: number): string {
  return text.length > max ? text.slice(0, max - 1) + '…' : text
}
