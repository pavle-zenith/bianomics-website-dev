/**
 * Pure helpers for editing the site's content files safely.
 * No network or env access here, so it is easy to test.
 */
import ts from 'typescript'

export interface EditResult {
  ok: boolean
  content?: string
  error?: string
  /** Name of the locked export this edit touches, if any. */
  locked?: string
}

/** Text in the file that the model wants replaced must appear exactly once. */
export function applyEdit(
  content: string,
  oldStr: string,
  newStr: string,
  opts: { fileName: string; allowLocked?: boolean } = { fileName: 'file.ts' },
): EditResult {
  if (!oldStr) return { ok: false, error: 'old_str is empty.' }
  if (oldStr === newStr) return { ok: false, error: 'old_str and new_str are identical.' }

  const first = content.indexOf(oldStr)
  if (first === -1) {
    return {
      ok: false,
      error:
        'old_str was not found. It must match the file exactly, including quotes, escapes and whitespace. Read the file again and copy the text exactly.',
    }
  }
  if (content.indexOf(oldStr, first + 1) !== -1) {
    return {
      ok: false,
      error: 'old_str appears more than once. Include more surrounding text so it is unique.',
    }
  }

  const locked = lockedExportAt(content, first, first + oldStr.length, opts.fileName)
  if (locked && !opts.allowLocked) {
    return {
      ok: false,
      locked,
      error: `This text is inside \`${locked}\`, which is marked as locked brand language (used verbatim, never paraphrased). Only change it if the user gave the exact new wording word for word. If they did, call edit_file again with confirm_locked: true. Otherwise do not edit it: tell them it is locked and ask for the exact wording.`,
    }
  }

  const next = content.slice(0, first) + newStr + content.slice(first + oldStr.length)
  const syntaxError = checkSyntax(next, opts.fileName)
  if (syntaxError) {
    return {
      ok: false,
      error: `That edit would break the file, so it was not applied: ${syntaxError}. Check quotes and escaping (e.g. an apostrophe inside a single-quoted string must be escaped or the string switched to double quotes).`,
    }
  }
  return { ok: true, content: next, locked: locked ?? undefined }
}

/** Returns a short description of the first syntax error, or null. */
export function checkSyntax(content: string, fileName: string): string | null {
  const out = ts.transpileModule(content, {
    fileName,
    reportDiagnostics: true,
    compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext },
  })
  const diag = out.diagnostics?.[0]
  if (!diag) return null
  const message = ts.flattenDiagnosticMessageText(diag.messageText, '\n')
  if (diag.file && diag.start !== undefined) {
    const { line } = diag.file.getLineAndCharacterOfPosition(diag.start)
    return `line ${line + 1}: ${message}`
  }
  return message
}

/**
 * Top-level exports whose doc comment says "locked", e.g.
 *   /** Locked brand language — used verbatim, never paraphrased. *\/
 *   export const brand = { ... }
 * Returns the export's name if [start, end) overlaps one.
 */
export function lockedExportAt(content: string, start: number, end: number, fileName: string): string | null {
  for (const region of lockedRegions(content, fileName)) {
    if (start < region.end && end > region.start) return region.name
  }
  return null
}

export function lockedRegions(content: string, fileName: string): { name: string; start: number; end: number }[] {
  const sf = ts.createSourceFile(fileName, content, ts.ScriptTarget.ES2022, true)
  const regions: { name: string; start: number; end: number }[] = []
  for (const stmt of sf.statements) {
    const comments = ts.getLeadingCommentRanges(content, stmt.pos) ?? []
    const commentText = comments.map((c) => content.slice(c.pos, c.end)).join('\n')
    if (!/\blocked\b/i.test(commentText)) continue
    let name = 'locked block'
    if (ts.isVariableStatement(stmt)) {
      const decl = stmt.declarationList.declarations[0]
      if (decl && ts.isIdentifier(decl.name)) name = decl.name.text
    }
    regions.push({ name, start: stmt.getStart(sf), end: stmt.end })
  }
  return regions
}

/** Case-insensitive search returning "file:line: text" hits. */
export function searchFiles(files: Record<string, string>, query: string, max = 40): string[] {
  const q = query.toLowerCase().trim()
  if (!q) return []
  const hits: string[] = []
  for (const [name, content] of Object.entries(files)) {
    const lines = content.split('\n')
    for (let i = 0; i < lines.length; i++) {
      if (lines[i].toLowerCase().includes(q)) {
        hits.push(`${name}:${i + 1}: ${lines[i].trim().slice(0, 240)}`)
        if (hits.length >= max) return hits
      }
    }
  }
  return hits
}

/** In-memory copy of the content files the agent is working on. */
export class WorkingSet {
  private original = new Map<string, string>()
  private current = new Map<string, string>()

  constructor(private load: (name: string) => Promise<string | null>) {}

  async get(name: string): Promise<string | null> {
    if (this.current.has(name)) return this.current.get(name)!
    const text = await this.load(name)
    if (text === null) return null
    this.original.set(name, text)
    this.current.set(name, text)
    return text
  }

  set(name: string, content: string): void {
    this.current.set(name, content)
  }

  changed(): { name: string; content: string }[] {
    const out: { name: string; content: string }[] = []
    for (const [name, content] of this.current) {
      if (this.original.get(name) !== content) out.push({ name, content })
    }
    return out
  }
}
