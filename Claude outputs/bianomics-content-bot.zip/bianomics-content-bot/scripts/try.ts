/**
 * Try the agent locally against a checkout of the site, no Slack or GitHub.
 * Prints the reply and the edits; with --write it saves them to disk.
 *
 *   ANTHROPIC_API_KEY=sk-ant-... npx tsx scripts/try.ts ../bianomics-website-dev "make the cost FAQ answer shorter"
 */
import Anthropic from '@anthropic-ai/sdk'
import { readdirSync, readFileSync, writeFileSync, existsSync } from 'node:fs'
import { join } from 'node:path'
import { runAgent } from '../lib/agent'

const [siteDir, ...rest] = process.argv.slice(2).filter((a) => a !== '--write')
const write = process.argv.includes('--write')
const request = rest.join(' ')
if (!siteDir || !request) {
  console.error('Usage: npx tsx scripts/try.ts <path-to-site> "<request>" [--write]')
  process.exit(1)
}
const contentDir = join(siteDir, process.env.CONTENT_DIR || 'src/content')
const files = readdirSync(contentDir).filter((f) => f.endsWith('.ts'))
const readonly = (process.env.READONLY_FILES ?? 'types.ts,index.ts,legal.ts').split(',')

const result = await runAgent({
  client: new Anthropic(),
  model: process.env.ANTHROPIC_MODEL || 'claude-sonnet-5-5',
  history: [{ role: 'user', content: request }],
  files,
  readonly,
  load: async (name) => {
    const p = join(contentDir, name)
    return existsSync(p) ? readFileSync(p, 'utf8') : null
  },
  siteName: 'Bianomics',
})

console.log('\nReply:\n' + result.reply + '\n')
for (const e of result.edits) {
  console.log(`--- ${e.description} (${e.file})${e.locked ? ' [LOCKED]' : ''}`)
  console.log('before:', e.before)
  console.log('after: ', e.after, '\n')
}
if (write) {
  for (const c of result.changed) writeFileSync(join(contentDir, c.name), c.content)
  console.log(`Wrote ${result.changed.length} file(s).`)
}
