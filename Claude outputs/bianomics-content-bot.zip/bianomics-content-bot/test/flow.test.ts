/**
 * End-to-end: Slack message -> agent -> PR -> preview -> approve -> live,
 * with Slack, GitHub and the Claude API faked at the fetch level.
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'

Object.assign(process.env, {
  SLACK_BOT_TOKEN: 'xoxb-test',
  SLACK_SIGNING_SECRET: 'x',
  ALLOWED_SLACK_USER_IDS: 'UBIANCA',
  ANTHROPIC_API_KEY: 'sk-test',
  GITHUB_TOKEN: 'ghp-test',
  GITHUB_REPO: 'pavle-zenith/bianomics-website-dev',
  GITHUB_WEBHOOK_SECRET: 'x',
  SITE_URL: 'https://bianomics.com',
})

const faq = readFileSync(new URL('./fixtures/faq.ts', import.meta.url), 'utf8')
const OLD = "'It depends on what you need and how much of the system you bring in."
const NEW = "'Every engagement is scoped to what you need."

const calls: { url: string; method: string; body: any }[] = []
let claudeTurn = 0
const repo = { main: 'sha-main', branches: {} as Record<string, string>, prs: [] as any[], committed: '' }

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: { 'content-type': 'application/json' } })
}

globalThis.fetch = (async (input: any, init: any = {}) => {
  const url = typeof input === 'string' ? input : input.url
  const method = init.method ?? (typeof input === 'object' ? input.method : 'GET')
  const rawBody = init.body ?? (typeof input === 'object' && input.body ? await input.text() : undefined)
  const body = rawBody ? JSON.parse(rawBody) : undefined
  calls.push({ url, method, body })

  // ---- Claude API
  if (url.includes('api.anthropic.com')) {
    claudeTurn++
    const base = { id: 'msg_' + claudeTurn, type: 'message', role: 'assistant', model: body.model, usage: { input_tokens: 1, output_tokens: 1 } }
    if (claudeTurn === 1) return json({ ...base, stop_reason: 'tool_use', content: [{ type: 'tool_use', id: 't1', name: 'search', input: { query: 'how much does it cost' } }] })
    if (claudeTurn === 2) {
      // The search result must have been fed back to the model.
      const last = body.messages.at(-1).content[0].content
      assert.match(last, /faq\.ts:\d+:/)
      return json({ ...base, stop_reason: 'tool_use', content: [{ type: 'tool_use', id: 't2', name: 'edit_file', input: { file: 'faq.ts', old_str: OLD, new_str: NEW, description: 'FAQ: How much does it cost?' } }] })
    }
    assert.equal(body.messages.at(-1).content[0].content, 'Edit applied.')
    return json({ ...base, stop_reason: 'end_turn', content: [{ type: 'text', text: 'Updated the *cost* FAQ answer.' }] })
  }

  // ---- Slack
  if (url.startsWith('https://slack.com/api/')) {
    const method = url.split('/').pop()
    if (method === 'chat.postMessage') return json({ ok: true, ts: '200.000' + calls.length })
    if (method === 'chat.update') return json({ ok: true })
    if (method === 'conversations.replies')
      return json({ ok: true, messages: [{ ts: '100.1', user: 'UBIANCA', text: '<@UBOT> make the cost FAQ answer start with "Every engagement is scoped to what you need."' }, { ts: '200.0001', bot_id: 'B1', text: 'On it…' }] })
    return json({ ok: false, error: 'unknown ' + method })
  }

  // ---- GitHub
  const gh = url.replace('https://api.github.com/repos/pavle-zenith/bianomics-website-dev', '')
  if (gh === '/pulls?state=open&per_page=100') return json(repo.prs.filter((p) => p.state === 'open'))
  if (gh.startsWith('/contents/src/content?')) return json(['faq.ts', 'site.ts', 'types.ts', 'index.ts', 'legal.ts'].map((name) => ({ name, type: 'file' })))
  if (gh.startsWith('/contents/src/content/faq.ts')) return new Response(faq)
  if (gh.startsWith('/contents/src/content/')) return new Response('export const x = 1\n')
  if (gh === '/git/ref/heads/main') return json({ object: { sha: repo.main } })
  if (gh === '/git/refs' && method === 'POST') { repo.branches[body.ref.replace('refs/heads/', '')] = body.sha; return json({}) }
  if (gh.startsWith('/git/commits/') && method === 'GET') return json({ tree: { sha: 'tree-base' }, parents: [{ sha: 'sha-before' }] })
  if (gh === '/git/trees') { repo.committed = body.tree[0].content; assert.equal(body.tree[0].path, 'src/content/faq.ts'); return json({ sha: 'tree-new' }) }
  if (gh === '/git/commits' && method === 'POST') return json({ sha: 'sha-commit-1' })
  if (gh.startsWith('/git/refs/heads/') && method === 'PATCH') return json({})
  if (gh.startsWith('/git/refs/heads/') && method === 'DELETE') return new Response(null, { status: 204 })
  if (gh === '/pulls' && method === 'POST') {
    const pr = { number: 7, title: body.title, body: body.body, state: 'open', merged: false, merge_commit_sha: null, html_url: 'https://github.com/x/pull/7', head: { ref: body.head, sha: 'sha-commit-1' }, base: { ref: 'main' } }
    repo.prs.push(pr)
    return json(pr)
  }
  if (gh === '/commits/sha-commit-1/pulls') return json(repo.prs)
  if (gh === '/pulls/7' && method === 'GET') return json(repo.prs[0])
  if (gh === '/pulls/7/merge') {
    assert.equal(body.sha, 'sha-commit-1')
    Object.assign(repo.prs[0], { state: 'closed', merged: true, merge_commit_sha: 'sha-merge' })
    return json({ merged: true })
  }
  if (gh === '/commits/sha-merge/pulls') return json(repo.prs)
  throw new Error(`Unmocked ${method} ${url}`)
}) as typeof fetch

const slackCalls = (m: string) => calls.filter((c) => c.url.endsWith('/' + m))

test('full flow', async () => {
  const flow = await import('../lib/flow')

  // 1. Bianca's message
  await flow.handleMessage({ channel: 'D123', threadTs: '100.1', messageTs: '100.1', user: 'UBIANCA', text: '<@UBOT> make the cost FAQ answer start with "Every engagement is scoped to what you need."', botUserId: 'UBOT' })
  assert.equal(claudeTurn, 3)
  assert.match(repo.committed, /Every engagement is scoped to what you need\./)
  assert.doesNotMatch(repo.committed, /It depends on what you need/)
  const pr = repo.prs[0]
  assert.ok(pr.head.ref.startsWith('content-bot/'))
  assert.match(pr.body, /<!-- content-bot:D123:100\.1 -->/)
  const update = slackCalls('chat.update').at(-1)!.body
  assert.match(JSON.stringify(update.blocks), /FAQ: How much does it cost\?/)
  assert.match(JSON.stringify(update.blocks), /Building a preview/)
  // The history sent to Claude had the mention stripped and the status message dropped.
  const firstClaude = calls.find((c) => c.url.includes('anthropic'))!.body
  assert.equal(firstClaude.messages.length, 1)
  assert.doesNotMatch(firstClaude.messages[0].content, /UBOT/)

  // 2. Vercel preview ready
  await flow.handleDeploymentStatus({ deployment_status: { state: 'success', environment_url: 'https://preview.vercel.app' }, deployment: { sha: 'sha-commit-1', environment: 'Preview', ref: pr.head.ref } })
  const preview = slackCalls('chat.postMessage').at(-1)!.body
  assert.equal(preview.thread_ts, '100.1')
  assert.match(JSON.stringify(preview.blocks), /preview\.vercel\.app/)
  const approve = preview.blocks[1].elements[0]
  assert.equal(approve.action_id, 'approve')

  // 3. Someone not allowed clicks approve -> refused, nothing merged
  await flow.handleInteraction({ type: 'block_actions', user: { id: 'USTRANGER' }, channel: { id: 'D123' }, container: { message_ts: '300.1' }, message: { ts: '300.1', thread_ts: '100.1' }, actions: [{ action_id: 'approve', value: approve.value }] })
  assert.equal(calls.some((c) => c.url.endsWith('/pulls/7/merge')), false)

  // 4. Bianca approves -> merged at the previewed sha
  await flow.handleInteraction({ type: 'block_actions', user: { id: 'UBIANCA' }, channel: { id: 'D123' }, container: { message_ts: '300.1' }, message: { ts: '300.1', thread_ts: '100.1' }, actions: [{ action_id: 'approve', value: approve.value }] })
  assert.ok(calls.some((c) => c.url.endsWith('/pulls/7/merge')))
  assert.match(JSON.stringify(slackCalls('chat.update').at(-1)!.body), /Approved by <@UBIANCA>/)

  // 5. Production deploy -> "It's live" with Undo
  await flow.handleDeploymentStatus({ deployment_status: { state: 'success', environment_url: 'https://bianomics.com' }, deployment: { sha: 'sha-merge', environment: 'Production', ref: 'main' } })
  const live = slackCalls('chat.postMessage').at(-1)!.body
  assert.match(JSON.stringify(live.blocks), /It's live/)
  assert.equal(live.blocks[1].elements[0].action_id, 'undo')
})
