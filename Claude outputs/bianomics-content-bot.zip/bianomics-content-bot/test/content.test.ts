import { test } from 'node:test'
import assert from 'node:assert/strict'
import { readFileSync, readdirSync } from 'node:fs'
import { applyEdit, checkSyntax, lockedRegions, searchFiles } from '../lib/content'

const dir = new URL('./fixtures/', import.meta.url)
const read = (f: string) => readFileSync(new URL(f, dir), 'utf8')
const site = read('site.ts')
const faq = read('faq.ts')

test('all real content files parse cleanly', () => {
  for (const f of readdirSync(dir)) assert.equal(checkSyntax(read(f), f), null, f)
})

test('finds the locked exports in site.ts (brand + snapshot)', () => {
  const names = lockedRegions(site, 'site.ts').map((r) => r.name)
  assert.deepEqual(names.sort(), ['brand', 'snapshot'])
})

test('plain FAQ edit applies', () => {
  const old = "'Either works. You can start with one practice"
  const res = applyEdit(faq, old, "'Absolutely. You can start with one practice", { fileName: 'faq.ts' })
  assert.ok(res.ok, res.error)
  assert.match(res.content!, /Absolutely\. You can start/)
  assert.equal(res.locked, undefined)
})

test('unescaped apostrophe in single-quoted string is rejected', () => {
  const old = "'Either works. You can start with one practice"
  const res = applyEdit(faq, old, "'Either works. You can't start with one practice", { fileName: 'faq.ts' })
  assert.equal(res.ok, false)
  assert.match(res.error!, /break the file/)
})

test('locked brand text needs confirm_locked', () => {
  const old = "tagline: 'Your purpose is our power source.'"
  const blocked = applyEdit(site, old, "tagline: 'Purpose powers us.'", { fileName: 'site.ts' })
  assert.equal(blocked.ok, false)
  assert.equal(blocked.locked, 'brand')
  const allowed = applyEdit(site, old, "tagline: 'Purpose powers us.'", { fileName: 'site.ts', allowLocked: true })
  assert.ok(allowed.ok)
  assert.equal(allowed.locked, 'brand')
})

test('non-locked site.ts text (about intro) is not flagged', () => {
  const res = applyEdit(site, "eyebrow: 'About us'", "eyebrow: 'Who we are'", { fileName: 'site.ts' })
  assert.ok(res.ok, res.error)
  assert.equal(res.locked, undefined)
})

test('ambiguous and missing old_str are rejected', () => {
  assert.equal(applyEdit(site, 'Bianomics', 'X', { fileName: 'site.ts' }).ok, false)
  assert.equal(applyEdit(site, 'not in the file at all', 'X', { fileName: 'site.ts' }).ok, false)
})

test('search finds FAQ question', () => {
  const hits = searchFiles({ 'faq.ts': faq }, 'how much does it cost')
  assert.equal(hits.length, 1)
  assert.match(hits[0], /^faq\.ts:\d+:/)
})
