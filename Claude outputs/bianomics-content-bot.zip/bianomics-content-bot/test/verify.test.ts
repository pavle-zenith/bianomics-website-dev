import { test } from 'node:test'
import assert from 'node:assert/strict'
import { createHmac } from 'node:crypto'
import { verifyGithubRequest, verifySlackRequest } from '../lib/verify'
import { threadToHistory } from '../lib/agent'

test('slack signature', () => {
  const body = 'token=x&payload=%7B%7D'
  const ts = '1730000000'
  const sig = 'v0=' + createHmac('sha256', 's3cret').update(`v0:${ts}:${body}`).digest('hex')
  assert.ok(verifySlackRequest(body, ts, sig, 's3cret', 1730000010))
  assert.equal(verifySlackRequest(body, ts, sig, 'wrong', 1730000010), false)
  assert.equal(verifySlackRequest(body, ts, sig, 's3cret', 1730009999), false, 'stale timestamp')
})

test('github signature', () => {
  const body = '{"a":1}'
  const sig = 'sha256=' + createHmac('sha256', 'gh').update(body).digest('hex')
  assert.ok(verifyGithubRequest(body, sig, 'gh'))
  assert.equal(verifyGithubRequest(body, sig, 'nope'), false)
})

test('thread history: roles, mention stripping, merging, trimming', () => {
  const h = threadToHistory(
    [
      { ts: '1', text: '<@UBOT> change the FAQ cost answer' },
      { ts: '2', text: 'Done, preview soon', bot_id: 'B1' },
      { ts: '3', text: 'Preview ready', bot_id: 'B1' },
      { ts: '4', text: 'make it shorter' },
      { ts: '5', text: 'On it…', bot_id: 'B1' },
    ],
    { skipTs: ['5'], botUserId: 'UBOT' },
  )
  assert.deepEqual(h, [
    { role: 'user', content: 'change the FAQ cost answer' },
    { role: 'assistant', content: 'Done, preview soon\n\nPreview ready' },
    { role: 'user', content: 'make it shorter' },
  ])
})
