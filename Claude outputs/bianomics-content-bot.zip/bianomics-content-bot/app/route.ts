export function GET() {
  return new Response('Bianomics content bot is running.')
}
