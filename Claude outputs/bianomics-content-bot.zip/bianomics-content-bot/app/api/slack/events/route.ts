import { after } from 'next/server'
import { config } from '@/lib/config'
import { handleMessage } from '@/lib/flow'
import { postMessage } from '@/lib/slack'
import { verifySlackRequest } from '@/lib/verify'

export const maxDuration = 300

interface SlackEvent {
  type: string
  subtype?: string
  channel: string
  channel_type?: string
  user?: string
  bot_id?: string
  text?: string
  ts: string
  thread_ts?: string
}

export async function POST(request: Request) {
  const raw = await request.text()
  const ok = verifySlackRequest(
    raw,
    request.headers.get('x-slack-request-timestamp'),
    request.headers.get('x-slack-signature'),
    config.slackSigningSecret,
  )
  if (!ok) return new Response('Bad signature', { status: 401 })

  const body = JSON.parse(raw)
  if (body.type === 'url_verification') return Response.json({ challenge: body.challenge })

  // We always ack within 3s, so a retry means a duplicate. Drop it.
  if (request.headers.get('x-slack-retry-num')) return new Response('ok')

  if (body.type === 'event_callback') {
    const event = body.event as SlackEvent
    const botUserId: string | undefined = body.authorizations?.[0]?.user_id
    const isDm = event.type === 'message' && event.channel_type === 'im'
    const isMention = event.type === 'app_mention'
    const fromPerson = !event.bot_id && !event.subtype && !!event.user

    if ((isDm || isMention) && fromPerson) {
      const threadTs = event.thread_ts ?? event.ts
      if (!config.allowedUsers.includes(event.user!)) {
        after(() =>
          postMessage({
            channel: event.channel,
            threadTs,
            text: "Sorry, I can only take website changes from approved people. Ask Pavle if you need access.",
          }).catch((e) => console.error(e)),
        )
      } else {
        after(() =>
          handleMessage({
            channel: event.channel,
            threadTs,
            messageTs: event.ts,
            user: event.user!,
            text: event.text ?? '',
            botUserId,
          }).catch((e) => console.error('handleMessage crashed', e)),
        )
      }
    }
  }

  return new Response('ok')
}
