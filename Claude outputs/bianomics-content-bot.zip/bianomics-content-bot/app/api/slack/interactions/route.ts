import { after } from 'next/server'
import { config } from '@/lib/config'
import { handleInteraction } from '@/lib/flow'
import { verifySlackRequest } from '@/lib/verify'

export const maxDuration = 300

export async function POST(request: Request) {
  const raw = await request.text()
  const ok = verifySlackRequest(
    raw,
    request.headers.get('x-slack-request-timestamp'),
    request.headers.get('x-slack-signature'),
    config.slackSigningSecret,
  )
  if (!ok) return new Response('Bad signature', { status: 401 })

  const payload = JSON.parse(new URLSearchParams(raw).get('payload') ?? '{}')
  if (payload.type === 'block_actions') {
    after(() => handleInteraction(payload).catch((e) => console.error('handleInteraction crashed', e)))
  }
  return new Response('')
}
