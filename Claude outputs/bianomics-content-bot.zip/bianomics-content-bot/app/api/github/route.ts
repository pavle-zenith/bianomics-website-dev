import { after } from 'next/server'
import { config } from '@/lib/config'
import { handleDeploymentStatus } from '@/lib/flow'
import { verifyGithubRequest } from '@/lib/verify'

export const maxDuration = 300

export async function POST(request: Request) {
  const raw = await request.text()
  if (!verifyGithubRequest(raw, request.headers.get('x-hub-signature-256'), config.githubWebhookSecret)) {
    return new Response('Bad signature', { status: 401 })
  }
  const event = request.headers.get('x-github-event')
  if (event === 'ping') return new Response('pong')
  if (event === 'deployment_status') {
    const payload = JSON.parse(raw)
    after(() => handleDeploymentStatus(payload).catch((e) => console.error('deployment_status failed', e)))
  }
  return new Response('ok')
}
